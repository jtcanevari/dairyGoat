library(dplyr); library(lubridate); library(shiny); library(plyr); library(ggplot2); library(grid)

#setwd("C:\\Temp\\DWLochaber\\code\\LOC_Goatbook\\LOC_Goatbook")
# Define server logic:

shinyServer(function(input, output) {
  
  output$myList <- renderUI({
    textInput(inputId = "gtag", label = "Goat id:", value = "")
  })
  
  
  output$myNumbers <- renderUI({
    selectInput("lactNo", "Lactation No.:", unique(out1$lact[out1$CowNumber == input$gtag]))
  })
  
  cows <- read.csv("LOC_cows.csv", sep = ",", header = TRUE)
  calv <- read.csv("LOC_calv.csv", sep = ",", header = TRUE)
  join <- read.csv("LOC_joinings.csv", sep = ",", header = TRUE)
  doff <- read.csv("LOC_DryOffs.csv", sep = ",", header = TRUE)
  cull <- read.csv("LOC_culls.csv", sep = ",", header = TRUE)
  ptest <- read.csv("LOC_pregTest.csv", sep = ",", header = TRUE)
  CAEr <- read.csv("LOC_CAEresults.csv", sep = ",", header = TRUE)
  prod <- read.table("LOC_prod.csv", header = TRUE, sep = ",")
  prevl <- read.csv('LOC_lastlac.csv')
  colnames(prevl) <- c("EID","Eartag","LactNo.", "Total Milk (L)")
  weights<- read.csv("LOC_weights.csv")
  
  #simplify tables
  
  tcows <- cows[,c(1,8,10)]
  tcows$Event <- "Birth"
  tcows$Comment <- ""
  
  tcalv <- calv[,c(2,3)] #agregar cowNumber
  tcalv$CowNumber <- tcows$CowNumber[match(tcalv$CowKey,tcows$CowKey)]
  tcalv <- tcalv[,c(1,3,2)]
  tcalv$Event <- "Kidding"
  tcalv$Comment <- ""
  
  tjoin <- join[,c(10,2,5)]
  tjoin$Event <- "Joining"
  tjoin$Comment <- ""
  
  tdoff <- doff[,c(2,7,3)]
  tdoff$Event <- "Drying-Off"
  tdoff$Comment <- ""
  
  tcull <- cull[,c(2,3)] #agregar cowNumber
  tcull$CowNumber <- tcows$CowNumber[match(tcull$CowKey,tcows$CowKey)]
  tcull <- tcull[,c(1,3,2)]
  tcull$Event <- "Culling"
  tcull$Comment <- cull$RemovalReason1
  
  tptest <- ptest[,c(7,2,4,5)]
  tptest$Event <- "PregTest"
  tptest <- tptest[,c(1,2,3,5,4)]
  tptest$PregCheckResult<- revalue(tptest$PregCheckResult, c("Yes"="Pregnant", "-" = "Empty"))
  
  tCAE <- CAEr[,c(2:4)]
  tCAE$CowKey <- cows$CowKey[match(tCAE$CowNumber,cows$CowNumber)]
  tCAE$etype <- "CAE test"
  tCAE <- tCAE[,c(4,1,3,5,2)]
  
  #use same colnames for all
  
  colnames(tcows) <- colnames(tcalv) <- colnames(tjoin) <- colnames(tdoff) <- colnames(tcull) <- colnames(tptest) <- colnames(tCAE) <- c("CowKey", "Eartag","EventDate","EventType", "Comment")
  
  out <- rbind(tcows,tcalv,tjoin,tdoff,tcull,tptest,tCAE)
  out$EventDate <- dmy(out$EventDate)
  out<- arrange(out,Eartag,EventDate)
  
  #gtag <- 15357
  dataInput <- reactive({
    t <- subset(out, Eartag == input$gtag)
    t <- t[,c(2:5)]
    t$EventDate <- as.character(t$EventDate)
    t
  })
  
  output$myTable <- renderTable({
    
    dataInput()
    
  },
  include.rownames=FALSE)
  
  ##########################
  #weights
  
  weights$VID <- gsub("L","",weights$VID)
  weights$VID <- gsub("G","",weights$VID)
  weights$VID <- gsub("F","",weights$VID)
  
  weights$CowKey <- cows$CowKey[match(weights$VID, cows$CowNumber)]
  weights$DOB <- cows$BirthDate[match(weights$VID, cows$CowNumber)]
  
  weights$DOB <- dmy(weights$DOB)
  weights$Date <- ymd(weights$Date)
  weights$age <- as.numeric((weights$Date - weights$DOB) / 30.4)
  weights$age <- ceiling(weights$age)
  weights <- weights[weights$age < 84 & weights$age>0,] #less than 10 years
  weights <- unique(weights)
  
  #agregate weights by median/month of age and get a plot to display at the back
  
  weights.median <- aggregate(weights$Weight, by = list(weights$age),  FUN = median)
  colnames(weights.median) <- c("age", "mweight")
  # gtag <- 101
  dataInput2 <- reactive({
    
    gtag <- input$gtag
    tweight <- subset(weights, weights$VID == gtag)
    
    
    # Scatter plot:
    ggplot(data = tweight, aes(age, Weight)) +
      geom_point() +
      stat_smooth(data=weights.median, aes(x=age, y=mweight), size = 0.5,
                  alpha = 0.2, col = "gray")+
      # geom_line() +
      scale_x_continuous(breaks=seq(0,84,12),
                         labels=seq(0,7,1))+
            ylim(0, 120) +
      # geom_hline(yintercept=35, linetype="dotted") +
      ylab("Weight (Kg)") +
      xlab("Age (Years)")
    
                        })
    
    output$distPlot1 <- renderPlot({
      dataInput2()
      
    })
    
    
    # get the latest weight
    
    output$table2 <- renderTable({
      
      gtag <- input$gtag
      lweight <- subset(weights, weights$VID == gtag)
      lweight <- lweight[lweight$Date == max(lweight$Date),]
      lweight$Date <- as.character(lweight$Date)
      lweight <- lweight[,c(2,3,4,7)]
      colnames(lweight) <- c("Eartag","Weight","Date Weighed", "Age")
      lweight$Age <- round(lweight$Age,2)
      lweight$Age <- paste(lweight$Age, "Months", " ")
      lweight
    },
    include.rownames=FALSE)
    
  
  ################################################################# prod
  
  
  # Simplify the production table:
  prod <- prod[,c(1:3,10)]
  prod$LactNo <- NA
  
  # Calculate days in milk:
  pcalv <- calv[,c(1:3,13)]
  
  # Add a flag to the production table tell us that this is a production event:
  prod$etype <- 0
  prod <- prod[,c(1,2,3,5,4,6)]
  
  # Add a flag to the calvings table to tell us that this is a calving event:
  pcalv$HTLitreTot <- 0 #just to make it equal to the prod table and be able to rbind
  pcalv$etype <- 1
  
  
  names(prod) <- names(pcalv) <- c("ekey", "cowkey", "edate","lact", "htlitretot", "etype")
  out1 <- rbind(pcalv, prod)
  
  # Sort the data by cowkey, then by edate:
  out1$edate <- dmy(out1$edate)
  out1 <- out1[order(out1$cowkey, out1$edate),]
  
  # Calculate a running total for etype (this will increase by one every time the cow calves):
  out1$nlact <- cumsum(out1$etype)
  
  # Create a subset of out with the calvings only:
  id <- out1$etype == 1
  unique <- out1[id,]
  
  # Take the edate from data frame unique (i.e. the calving date) and add it to data frame out matching by nlact:
  out1$cdate <- unique$edate[match(out1$nlact, unique$nlact)]
  
  # Take the lactNo from unique as well
  out1$lact <- unique$lact[match(out1$nlact, unique$nlact)]
  
  # Calculate days in milk
  # out$edate <- ymd(out$edate)
  # out$cdate <- ymd(out$cdate)
  out1$DIM <- as.numeric(out1$edate - out1$cdate)
  id <- out1$etype == 0
  out1 <- out1[id,]
  out1$DIM <- as.numeric(out1$edate - out1$cdate)
  
  # Only use those DIMs that are less than 300:
  out1 <- subset(out1, DIM < 300)
  out1$CowNumber <- cows$CowNumber[match(out1$cowkey, cows$CowKey)]
  out1 <- arrange(out1, CowNumber, desc(lact))
  
  output$distPlot <- renderPlot({
    
    gtype <- input$gtype
    tprod <- subset(out1, lact == input$lactNo & CowNumber == input$gtag) #fijate que necesitas lactno en out
    
    pscatter <- ggplot() +
      geom_point(data = tprod, aes(x = DIM, y = htlitretot)) +
      geom_line(data = out1[out1$lact == input$lactNo,], aes(x=DIM, y=htlitretot),stat="smooth",method = "lm",
                size = 1.5,
                alpha = 0.07)+
      xlab("Days in milk") +
      ylab("Milk volume (L)") +
      xlim(0,300) +
      ylim(0,6)
    
    # Alternative, fit mean milk yield as a function of days in milk with shaded area to identify uncertainty around the mean:
    psmooth <- ggplot(data = tprod, aes(x = DIM, y = htlitretot)) +
      geom_smooth() +
      geom_line(data = out1[out1$lact == input$lactNo,], aes(x=DIM, y=htlitretot),stat="smooth",method = "lm",
                size = 1.5,
                alpha = 0.1)+
      xlab("Days in milk") +
      ylab("Milk volume (L)") +
      xlim(0, 300) +
      ylim(0, 6)
    # coord_fixed(ratio = 5 / 1)
    
    pscattersmooth <- ggplot(data = tprod, aes(x = DIM, y = htlitretot)) +
      geom_smooth() +
      geom_point() +
      geom_line(data = out1[out1$lact == input$lactNo,], aes(x=DIM, y=htlitretot),stat="smooth",method = "lm",
                size = 1.5,
                alpha = 0.1)+
      xlab("Days in milk") +
      ylab("Milk volume (L)") +
      xlim(0, 300) +
      ylim(0, 6)
    # coord_fixed(ratio = 5 / 1)
    
    switch(gtype, Scatter = pscatter, Smooth = psmooth, Both = pscattersmooth)
    
  })
  
  output$pltable <- renderTable({
    tprevl <- subset(prevl, Eartag == input$gtag & LactNo. == (as.numeric(input$lactNo) - 1))
    tprevl <- tprevl[,c(2:4)]
    Q1 <- round(quantile(prevl$`Total Milk (L)`[prevl$LactNo. == (as.numeric(input$lactNo) - 1)],.25, na.rm = TRUE))
    Q3 <- round(quantile(prevl$`Total Milk (L)`[prevl$LactNo. == (as.numeric(input$lactNo) - 1)],.75, na.rm = TRUE))
    tprevl$herd_median <- paste(median(prevl$`Total Milk (L)`[prevl$LactNo. == (as.numeric(input$lactNo) - 1)]),"(",Q1,",",Q3,")")
    colnames(tprevl) <- c("Eartag", "Lact_No", "Total_Milk", "Median_Herd (Q1,Q3)")
    ttprevl <- tprevl[,c(2:4)]
    ttprevl
  }, include.rownames=FALSE)
  
}
)

