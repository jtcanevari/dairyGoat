library(shiny)

shinyUI(fluidPage(
 
   # Application title
  titlePanel("Individual Goat Report"),
  sidebarPanel(
    uiOutput("myList"),
    uiOutput("myNumbers"),
    radioButtons(inputId = "gtype", label = "Type of plot:", choices = c("Scatter", "Smooth", "Both"), selected = "Scatter")
  ),
  
  mainPanel(
    h4("Lactation curve:"),
    plotOutput("distPlot"),
    tags$footer("Gray line at the back represents herd average milk yield for the selected lactation"),
    tags$br(),
    tags$br(),
    h4("Total milk yield previous lactation:"),
    tableOutput("pltable"),
    tags$br(),
    h4("Events recorded for this goat:"),
    # tags$img(src="myImage.png", align = "right"),
    tableOutput("myTable"),
    h4("Individual weights:"),
    plotOutput("distPlot1"),
    tags$footer("Gray line at the back shows herd average weights by age"),
    tags$br(),
    h4("Latest weight recorded:"),
    tableOutput("table2"),
    #supress error messages
    tags$style(type="text/css",
               ".shiny-output-error { visibility: hidden; }",
               ".shiny-output-error:before { visibility: hidden; }"
    )
             )
  ))