library(shiny)

shinyUI(fluidPage(
  
  # Application title
  titlePanel("Culling candidates"),
  
  # Sidebar with a slider input for the number of bins
  sidebarLayout(
    sidebarPanel(
      radioButtons(inputId = "gstate", label = "Lactation state:", choices = c("In_milk", "Dried_off"), selected = "In_milk"),
      h4("Highlighting criteria"),
      selectInput(inputId = "age_sel", label = "Age limit", seq(1,10,1),4),
      selectInput(inputId = "lact_sel", label = "Lactation limit", seq(1,10,1),3),
      selectInput(inputId = "lame_sel", label = "Lameness count", seq(1,5,1)),
      sliderInput(inputId = "mlastq_sel","Milk last lactation percentile", min = 0,max = 1, value = 0.25),
      sliderInput(inputId = "prodq_sel","Mean milk this lactation percentile", min = 0,max = 1, value = 0.25),
      submitButton("Update View")
    ),
    
    # Show a table
    mainPanel(
      dataTableOutput("myTable")
      
      
    )
  )  
)
) 

