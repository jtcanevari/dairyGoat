library(lubridate); library(DT); library(dplyr); library(data.table)

shinyServer(function(input, output) {
  
  # Read all needed tables
  cows <- read.csv("LOC_cows.csv")
  cull <- read.csv("LOC_culls.csv")
  calv <- read.csv("LOC_calv.csv")
  dof <- read.csv("LOC_DryOffs.csv")
  dis <- read.csv("LOC_diseases.csv")
  mlast <- read.csv("LOC_lastlac.csv")
  prod <- read.csv("LOC_prod.csv")
  
  # Keep only those not culled to date
  lcows <- cows[!cows$CowKey %in% cull$CowKey,]
  
  # Simplify cows table
  lcows <- lcows[,c(1,6,8,10)]
  
  # Attach latest kidding. Match function will look at the first match of the descending dates.
  calv$calvDate <- dmy(calv$calvDate)
  calv <- calv[which(calv$calvDate < max(dmy(prod$testDate))),]
  calv <- arrange(calv, CowKey, desc(calvDate))
  lcows$calvDate <- calv$calvDate[match(lcows$CowKey, calv$CowKey)]
  lcows$lactNo <- calv$LactNo[match(lcows$CowKey, calv$CowKey)]
  
  # Attach latest dof
  dof$doDate <- dmy(dof$doDate)
  dof<- arrange(dof, CowKey, desc(doDate))
  lcows$dofDate <- dof$doDate[match(lcows$CowKey,dof$CowKey)]
  
  # Get goats in milk and dries
  tmilkers <- lcows[!is.na(lcows$calvDate),]
  milkers <- tmilkers[tmilkers$calvDate > tmilkers$dofDate | is.na(tmilkers$dofDate),] 
  milkers <- milkers[!is.na(milkers$CowKey),]    #check with production data with a unique subset of                                                      CowKey in last week prod; then kill the culled
  
  # tdries <- tmilkers[tmilkers$calvDate < tmilkers$dofDate,]
  # dries <- tdries[!is.na(tdries$CowKey),]
  
  # get count of lameness
  dis$count <- ave(rep(1, nrow(dis)), dis$CowKey, dis$Ailment, FUN = seq_along)
 
  dis <- as.data.table(dis)
  dis.1 <- dis[dis[, .I[which.max(count)], by=CowKey]$V1]
 
  lame <- dis.1[dis.1$Ailment == "lame-infection",]
  
  ##### work with milkers #####
  
  #get milk last lactation
  mlast$CowKey <- cows$CowKey[match(mlast$eartag, cows$CowNumber)]
  milkers.1 <- merge(milkers, mlast[,c(3:5)], by.x=c("CowKey", "lactNo"), by.y=c("CowKey", "LactNo"), all.x=TRUE, all.y=FALSE)
  
  #get diseases attached
  milkers.1$lameFreq <- lame$count[match(milkers.1$CowKey, lame$CowKey)]
  
  #get age today
  milkers.1$BirthDate <- dmy(milkers.1$BirthDate)
  milkers.1$age <- round(as.numeric(max(dmy(prod$testDate)) - milkers.1$BirthDate) / 365, 1)
  
  # Get DIM today
  # milkers.1$DIM <- as.numeric(today() - milkers.1$calvDate)
  milkers.1$DIM <- as.numeric(max(dmy(prod$testDate)) - milkers.1$calvDate)
  
  # Get average daily lactation 
  tprod <- prod[prod$CowKey %in% milkers.1$CowKey,]
  tprod$calvDate <- milkers.1$calvDate[match(tprod$CowKey, milkers.1$CowKey)]
  tprod$testDate <- dmy(tprod$testDate)
  tprod <- tprod[tprod$testDate > tprod$calvDate,]
  mprod <- aggregate(HTLitreTot ~ CowKey,data = tprod, FUN = mean)
  mprod$HTLitreTot <- round(mprod$HTLitreTot,1)
  milkers.1$meandmilk <- mprod$HTLitreTot[match(milkers.1$CowKey, mprod$CowKey)]
  
  # Colour cells
  
  #simplify tables
  milkers.2 <- milkers.1[,c(4,5,10,6,2,11,8,12,9)]
  colnames(milkers.2) <- c("VID", "DOB", "Age", "KiddingDate", "LactNo", "DIM", "MilkLastLact", "MeanDailyProd", "Lame_Freq")
  milkers.2$MilkLastLact <- as.numeric(as.character(milkers.2$MilkLastLac))  
  
  # Create output table
  
  dataInput <- reactive({
    
    #calculate limits
    prodq <- quantile(milkers.2$MeanDailyProd ,input$prodq_sel, na.rm =  TRUE)
    mlastq <- quantile(milkers.2$MilkLastLac,input$mlastq_sel, na.rm =  TRUE)
    age_sel <- input$age_sel
    lact_sel <- input$lact_sel
    lame_sel <- input$lame_sel
    
    # prodq <- 2
    # mlastq <- 250
    # age_sel <- 4
    # lact_sel <- 4
    # lame_sel <- 1
    
    milkers.2$tage <- ifelse(milkers.2$Age > age_sel, milkers.2$tage <- 1, milkers.2$tage <- 0)
    
    milkers.2$tlact <- ifelse(milkers.2$LactNo > lact_sel, milkers.2$tlact <- 1, milkers.2$tlact <- 0)
    
    milkers.2$tmlast <- ifelse(milkers.2$MilkLastLact <= mlastq, milkers.2$tmlast <- 1, milkers.2$mlast <- 0)
    
    milkers.2$tprod <- ifelse(milkers.2$MeanDailyProd <= prodq, milkers.2$tprod <- 1, milkers.2$tprod <- 0)
    
    milkers.2$tlame <- ifelse(milkers.2$Lame_Freq > lame_sel, milkers.2$tlame <- 1, milkers.2$tlame <- 0)
    
    milkers.2$Rmval_Score <-rowSums(milkers.2[c(10:15)], na.rm = TRUE)
    
    t <-  datatable(milkers.2[,c(1:9, 16)], rownames = FALSE) %>%
      formatStyle(columns = "MeanDailyProd" , 
                  background = styleInterval(prodq, c("red","white"))) %>%
      formatStyle(columns = "MilkLastLact" , 
                  background = styleInterval(mlastq, c("red", "white")))%>%
      formatStyle(columns = "Age" , 
                  background = styleInterval(age_sel, c("white", "red"))) %>%
      formatStyle(columns = "LactNo" , 
                  background = styleInterval(lact_sel, c("white", "red")))%>%
      formatStyle(columns = "Lame_Freq" , 
                  background = styleInterval(lame_sel, c("white", "red")))
    
    t
    
  })
  
  
  #################################################################################################
  
  #### Work with dries #####
  # 
  # # Obtain mlast from prod table
  #   prod$testDate <- dmy(prod$testDate)
  #   
  #   dries$milkprod <- NA
  #   mpfunc <- function(ck) {
  #     dries$milkprod[ck] <-  sum(subset(prod$HTLitreTot, prod$CowKey == dries$CowKey[ck] & prod$testDate > dries$calvDate[ck] & prod$testDate < dries$dofDate[ck] ),na.rm = TRUE)
  #     dries$milkprod[ck]
  #   }
  # 
  #  length(dries$milkprod[dries$milkprod > 0])
  #   
  #  # sapply(1:10, function(x) mpfunc(x))
  #   dries$milkprod <- sapply(1:nrow(dries), function(x) mpfunc(x))
  #   dries$milkprod <- round(dries$milkprod,0)
  # 
  # # Obtain total number of tests for each animal to calculate average prod.
  #   dries$ttcount <- NA
  # 
  #   tcfunc <- function(ck) {
  # 
  #     dries$ttcount[ck] <- length(subset(prod$HTLitreTot, prod$CowKey == dries$CowKey[ck] & prod$testDate > dries$calvDate[ck] & prod$testDate < dries$dofDate[ck] ),na.rm = TRUE)
  #     dries$ttcount[ck]
  #   }
  # 
  # 
  #   dries$ttcount <- sapply(1:nrow(dries), function(x) tcfunc(x))
  # 
  # ### Takes long time to run. Better load the table ready for use
  # 
  # # Calculate DIM and average prod and arrange by calvDate
  #   dries$DIM <- as.numeric(dries$dofDate - dries$calvDate)
  #   dries$avrgp <- round(dries$milkprod / dries$ttcount,1)
  #   dries <- arrange(dries, desc(calvDate))
  #   dries$BirthDate <- dmy(dries$BirthDate)
  # 
  # # Save table as csv
  #   write.table(dries, 'dries_culling.csv', sep = ",", row.names = FALSE)
  
  # Load the table a transform dates  
  dries <- read.csv('dries_culling.csv')
  dries$BirthDate <- ymd(dries$BirthDate) 
  dries$calvDate <- ymd(dries$calvDate)
  dries$dofDate <- ymd(dries$dofDate)
  
  
  # Attach diseases
  dries$lameFreq <- lame$count[match(dries$CowKey, lame$CowKey)]
  
  # Calculate Age  
  dries$age <- round(as.numeric(today() - dries$BirthDate) / 365, 1)
  
  
  tdries <- dries[,c(3,4,13,5,7,6,10,8,11,12)]
  colnames(tdries) <- c("VID", "DOB", "Age", "KiddingDate", "DofDate", "LactNo", "DIM", "MilkLastLact", "MeanDailyProd", "Lame_Freq")
  
  #create dataInput2
  
  ############
  dataInput2 <- reactive({
    
    #calculate limits
    prodq <- quantile(tdries$MeanDailyProd ,input$prodq_sel, na.rm =  TRUE)
    mlastq <- quantile(tdries$MilkLastLac,input$mlastq_sel, na.rm =  TRUE)
    age_sel <- input$age_sel
    lact_sel <- input$lact_sel
    lame_sel <- input$lame_sel
    
    # prodq <- 2
    # mlastq <- 250
    # age_sel <- 4
    # lact_sel <- 4
    # lame_sel <- 1
    
    tdries$tage <- ifelse(tdries$Age > age_sel, tdries$tage <- 1, tdries$tage <- 0)
    
    tdries$tlact <- ifelse(tdries$LactNo > lact_sel, tdries$tlact <- 1, tdries$tlact <- 0)
    
    tdries$tmlast <- ifelse(tdries$MilkLastLact <= mlastq, tdries$tmlast <- 1, tdries$mlast <- 0)
    
    tdries$tprod <- ifelse(tdries$MeanDailyProd <= prodq, tdries$tprod <- 1, tdries$tprod <- 0)
    
    tdries$tlame <- ifelse(tdries$Lame_Freq > lame_sel, tdries$tlame <- 1, tdries$tlame <- 0)
    
    tdries$Rmval_Score <-rowSums(tdries[c(11:16)], na.rm = TRUE)
    
    d <-  datatable(tdries[,c(1:10, 17)], rownames = FALSE) %>%
      formatStyle(columns = "MeanDailyProd" , 
                  background = styleInterval(prodq, c("red","white"))) %>%
      formatStyle(columns = "MilkLastLact" , 
                  background = styleInterval(mlastq, c("red", "white")))%>%
      formatStyle(columns = "Age" , 
                  background = styleInterval(age_sel, c("white", "red"))) %>%
      formatStyle(columns = "LactNo" , 
                  background = styleInterval(lact_sel, c("white", "red")))%>%
      formatStyle(columns = "Lame_Freq" , 
                  background = styleInterval(lame_sel, c("white", "red")))
    
    d
    
  })
  
  
  
  #############################################################################################
  # set output table #
  
  # create a switch between two tables
  
  output$myTable <- renderDataTable({
    gstate <- input$gstate  
    
    gmilkers <-  dataInput()
    gdries <- dataInput2()
    
    switch(gstate, In_milk = gmilkers, Dried_off = gdries)
    
  })
  
})

