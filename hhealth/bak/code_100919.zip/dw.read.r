library(dplyr); library(survival); library(RODBC); library(ggplot2); library(scales); library(tidyr)

# setwd("D:\\TEMP\\dairy\\data\\Massey-01_1993")
setwd("D:\\TEMP\\dairy\\data\\Meredith")


# Convert MDB to CSV (files up to 2 Gb size):
# https://www.rebasedata.com/convert-mdb-to-csv-online

# channel <- odbcConnectAccess("repro01_INT_v2004b.mdb")
#   dat <- sqlFetch(channel = channel, sqtable = "psm")
# close(channel)

aborts <- read.table("aborts.csv", header = TRUE, sep = ",")
names(aborts) <- c("abortkey", "cowkey", "abodate", "ecomment", "obsfm", "acause")
aborts$etype <- "ABORT"
aborts$abodate <- as.Date(as.character(aborts$abodate), format = "%d/%m/%Y")

calvings <- read.table("calvings.csv", header = TRUE, sep = ",")
calvings <- calvings[,1:5]
names(calvings) <- c("calvkey", "cowkey", "clvdate", "ctype", "assist")
calvings$etype <- "CALVE"
calvings$clvdate <- as.Date(as.character(calvings$clvdate), format = "%d/%m/%y")

diseases <- read.table("diseases.csv", header = TRUE, sep = ",")
diseases <- diseases[,c(1:4,6,7)]
names(diseases) <- c("diskey", "cowkey", "disdate", "distype", "reason", "qtr")
diseases$etype <- "DISEASE"
diseases$disdate <- as.Date(as.character(diseases$disdate), format = "%Y-%m-%d")

dryoffs <- read.table("dryoffs.csv", header = TRUE, sep = ",")
dryoffs <- dryoffs[,1:3]
names(dryoffs) <- c("dokey", "cowkey", "drydate")
dryoffs$etype <- "DRY"
dryoffs$drydate <- as.Date(as.character(dryoffs$drydate), format = "%d/%m/%y")

ent <- read.table("CowEnter.csv", header = TRUE, sep = ",")
names(ent) <- c("enkey", "cowkey", "entdate", "lactno", "sclass", "fertstat", "method", "transferid", "lactstatus", "duedate", "duesire", "comment")
ent$etype <- "ENTER"
ent$entdate <- as.Date(as.character(ent$entdate), format = "%Y-%m-%d")

ext <- read.table("CowExit.csv", header = TRUE, sep = ",")
names(ext) <- c("exkey", "cowkey", "extdate", "rfate", "r1reason", "r2reason", "r3reason")
ext$etype <- "EXIT"
ext$extdate <- as.Date(as.character(ext$extdate), format = "%d/%m/%y")

heats <- read.table("heats.csv", header = TRUE, sep = ",")
heats <- heats[,1:3]
names(heats) <- c("hkey", "cowkey", "headate")
heats$etype <- "HEAT"
heats$headate <- as.Date(as.character(heats$headate), format = "%d/%m/%y")

production <- read.table("production.csv", header = TRUE, sep = ",")
production <- production[,c(1:10)]
names(production) <- c("pkey", "cowkey", "prodate", "ltddate", "htdatpc", "htpropc", "htlacpc", "htvolam", "htvolpm", "htvoltot")
production$etype <- "PROD"
production$prodate <- as.Date(as.character(production$prodate), format = "%d/%m/%y")

psm <- read.table("psm.csv", header = TRUE, sep = ",")
psm <- psm[,1:4]
names(psm) <- c("psmkey", "cowkey", "psmcdate", "psmdate")
psm$etype <- "PSM"
psm$psmcdate <- as.Date(as.character(psm$psmcdate), format = "%d/%m/%y")
psm$psmdate <- as.Date(as.character(psm$psmdate), format = "%d/%m/%y")

repro <- read.table("vetReproExams.csv", header = TRUE, sep = ",")
repro <- repro[,1:6]
names(repro) <- c("rkey", "cowkey", "repdate", "rreason", "rdx1", "rdx2")
repro$etype <- "REPRO"
repro$repdate <- as.Date(as.character(repro$repdate), format = "%d/%m/%y")

servs <- read.table("servs.csv", header = TRUE, sep = ",")
servs <- servs[,1:6]
names(servs) <- c("skey", "cowkey", "serdate", "sertype", "sersire","sertech")
servs$etype <- "SERVE"
servs$serdate <- as.Date(as.character(servs$serdate), format = "%d/%m/%y")

whcs <- read.table("weightHeightCS.csv", header = TRUE, sep = ",")
whcs <- whcs[,c(1,2,3,5,4)]
names(whcs) <- c("wkey", "cowkey", "whcdate", "value", "etype")
whcs$whcdate <- as.Date(as.character(whcs$whcdate), format = "%d/%m/%y")

cows <- read.table("cows.csv", header = TRUE, sep = ",")
cows <- cows[,c(1,2,4,9,10)]
names(cows) <- c("cowkey", "herdid", "lid", "remdate", "birdate")
cows$etype <- "STOCK"
cows$remdate <- as.Date(as.character(cows$remdate), format = "%d/%m/%y")
cows$birdate <- as.Date(as.character(cows$birdate), format = "%d/%m/%y")


