# Return interval analyses:

# Heat and service date range:
start <- "01/06/1993"
end <- "31/07/1993"


# -------------------------------------------------------------------------------------------------------
# Assign services to each of the PSM dates listed for each animal. Once this is done we restrict the PSM date range down to the start and end dates listed above:

# Here we do a left join --- include all of the rows of x [cows], and the matching rows of y [heats]. Then select only those cows where a heat is recorded:
hcows <- cows %>%
  left_join(x = cows, y = heats, by = "cowkey") %>%
  select(cowkey, headate) %>%
  filter(!is.na(headate))
names(hcows) <- c("cowkey","edate")

# Another left join --- include all of the rows of x [cows], and the matching rows of y [servs]. 
scows <- cows %>%
  left_join(x = cows, y = servs, by = "cowkey") %>%
  select(cowkey,serdate) %>%
  filter(!is.na(serdate))
names(scows) <- c("cowkey","edate")

# Append the heats and services tables:
thserv <- rbind(hcows, scows)

# Cut the data down to the date range of interest:
thserv <- thserv %>%
  filter(edate >= as.Date(start, format = "%d/%m/%Y") & edate <= as.Date(end, format = "%d/%m/%Y"))

# Sort the data in order of cowkey then edate:
thserv <- thserv[order(thserv$cowkey, thserv$edate),] 

# Work out the length of the previous heat-service interval:
cuniq <- unique(thserv$cowkey)
thserv$int <- NA
rval <- thserv[1,]

for(i in 1:length(cuniq)){
  id <- thserv$cowkey == cuniq[i]
  trval <- thserv[id,]
  
  if(nrow(trval) > 1){  
  for(j in 2:nrow(trval)){
    trval$int[j] <- as.numeric(trval$edate[j] - trval$edate[j - 1])     
   }
  }
  rval <- rbind(rval, trval)
}

# Drop the first row:
thserv <- rval[-1,]
# id <- thserv$cowkey == 633; thserv[id,]

id <- !is.na(thserv$int)
thserv <- thserv[id,]

# Bin the heat-service intervals into 2-17 days, 18-24 days, 25-38 days, 39-45 days and 45+days:
thserv$icat <- NA
thserv$icat[thserv$int >= 2  & thserv$int <= 17] <- "02-17 days"
thserv$icat[thserv$int >= 18 & thserv$int <= 24] <- "18-24 days"
thserv$icat[thserv$int >= 25 & thserv$int <= 38] <- "25-38 days"
thserv$icat[thserv$int >= 39 & thserv$int <= 45] <- "39-45 days"
thserv$icat[thserv$int >  45] <- "45+ days"

rval <- table(thserv$icat)
rval <- round((rval / sum(rval)) * 100, digits = 0)
rval

windows(); ggplot(thserv, aes(x = int)) +
  # geom_histogram(binwidth = 1, colour = "gray", size = 1) +
  geom_histogram(aes(y = ..density..), position = "identity", binwidth = 1, colour = "gray", size = 1)+
  xlim(1, 100) +
  labs(x = "Heat-service interval (days)", y = "Density")



# -------------------------------------------------------------------------------------------------------

