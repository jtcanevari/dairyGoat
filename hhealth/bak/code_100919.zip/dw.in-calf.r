# In-calf rate analyses:

# PSMs between:
start <- "01/06/1993"
end <- "10/08/1993"


# -------------------------------------------------------------------------------------------------------
# Run dw.conception.r to return a list of successful service keys:

sskey <- dw.conception(start, end)
sskey <- sskey$sskey[sskey$sskey > 0]

# Left join. Include all of the rows of x [psm], and the matching rows of y [servs]. Left join important because some cows with a PSM may remain unmated.
tpsm <- psm %>%
  left_join(x = psm, y = servs, by = "cowkey") %>%
  filter(psmdate >= as.Date(start, format = "%d/%m/%Y") & psmdate <= as.Date(end, format = "%d/%m/%Y")) %>%
  filter(serdate >= psmdate)
dim(tpsm) # 504

# Add a flag to tpsm to indicate which services have been successful:
tpsm$status <- 0
tpsm$status[tpsm$skey %in% sskey] <- 1

tpsm[tpsm$psmkey == 144,]

# Now group the data by psmkey, taking the max of tpsm$conc:
tpsm <- tpsm %>%
  group_by(psmkey)
tpsm <- summarise(tpsm, psmdate = max(psmdate), skey = max(skey), serdate = max(serdate), status = max(status))
tpsm$psmcon <- tpsm$serdate - tpsm$psmdate

rval.km <- survfit(Surv(psmcon, status) ~ 1, conf.type = "none", type = "kaplan-meier", data = tpsm)
rval.km <- data.frame(time = rval.km$time, surv = rval.km$surv)
rval.km$csurv <- 1 - rval.km$surv

# rval.km[rval.km$time == 21,]
# rval.km[rval.km$time == 28,]

windows(); ggplot(rval.km, aes(x = time)) + 
  geom_step(aes(y = surv)) +
  xlab("PSM to conception interval (days)") +
  ylab("Cumulative proportion to experience event") +
  scale_color_brewer(name = "Method", palette = "Set1")




