# Body weight analyses:

# Bodyweights between:
start <- "01/06/2015"
end <- "30/06/2016"


# -------------------------------------------------------------------------------------------------------

# Left join. Include all of the rows of x [calvings], and the matching rows of y [whcs]. Left join important because some cows with a PSM may remain unmated.
twhc <- whcs %>%
  left_join(x = calvings, y = whcs, by = "cowkey") %>%
  filter(whcdate >= as.Date(start, format = "%d/%m/%Y") & whcdate <= as.Date(end, format = "%d/%m/%Y")) %>%
  mutate(dim = as.numeric(whcdate - clvdate)) %>%
  filter(dim >= 0 & dim < 400)
dim(twhc) # 10119

# Attach birth date:
twhc$birdate <- cows$birdate[match(twhc$cowkey, cows$cowkey)]

# Calculate age (in years) on date of weigh event:
twhc$wage <- round(as.numeric((twhc$whcdate - twhc$birdate)/365), digits = 0)

# Create age categories:
twhc$cwage <- twhc$wage
twhc$cwage[twhc$wage >= 4 & twhc$wage <= 8] <- 4
twhc$cwage[twhc$wage >  8] <- 5
# table(twhc$cwage)
twhc$cwage <- factor(twhc$cwage, levels = c(1,2,3,4,5), labels = c("1 yo", "2 yo", "3 yo", "4-8 yo", "8+ yo"))

windows(); ggplot(twhc, aes(x = dim, y = value)) + 
  geom_point() +
  facet_grid(cwage ~ .) +
  xlab("Days in milk") +
  ylab("Bodyweight (kg)") +
  scale_color_brewer(name = "Method", palette = "Set1")




