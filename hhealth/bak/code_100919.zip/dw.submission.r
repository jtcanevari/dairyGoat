# Submission rate analyses:

# PSMs between:
start <- "01/06/1993"
end <- "10/08/1993"


# -------------------------------------------------------------------------------------------------------
# Assign services to each of the PSM dates listed for each animal. Once this is done we restrict the PSM date range down to the start and end dates listed above:

# Here we do a left join --- include all of the rows of x [psm], and the matching rows of y [servs]. Left join important because some cows with a PSM may remain unmated.
tpsm <- psm %>%
  left_join(x = psm, y = servs, by = "cowkey")

# Check:
# id <- psm$cowkey == 150; psm[id,]
# id <- servs$cowkey == 150; servs[id,]
# id <- tpsm$cowkey == 150; tpsm[id,]

# Subtract serdate from psmdate:
tpsm$psmser <- as.numeric(tpsm$serdate - tpsm$psmdate)

# Drop those psm-service pairs with psmser intervals that are less than -7 days and greater than 150 days.
# Need to fix. PSM to service intervals could be greater than 150 days.
tpsm <- tpsm %>%
  filter(psmser >= -7 & psmser <= 150 | is.na(psmser)) %>%
  select(psmkey, cowkey, psmcdate, psmdate, skey, serdate, stype, ssire, psmser) %>%
  arrange(cowkey, psmdate, psmser)

# Now cut the data down to the PSM date range of interest:
# table(tpsm$psmdate)
tpsm <- tpsm %>%
  filter(psmdate >= as.Date(start, format = "%d/%m/%Y") & psmdate <= as.Date(end, format = "%d/%m/%Y"))

# Group by cowkey and select the minimum of psmser interval:
tpsm <- tpsm %>%
  group_by(cowkey)

rval <- data.frame(summarise(tpsm, psmdate = min(psmdate), serdate = min(serdate), stype = n_distinct(stype), psmser = min(psmser)))
rval$status <- ifelse(!is.na(rval$psmser), 1, 0)

# Look up birth date from stock table using akey as the key:
rval$birdate <- cows$birdate[match(rval$cowkey, cows$cowkey)]

# Calculate age (in years) on date of PSM date:
rval$psmage <- round(as.numeric((rval$psmdate - rval$birdate)/365), digits = 0)
rval$psmage[rval$psmage > 20] <- NA

# Create age categories:
rval$cpsmage <- rval$psmage
rval$cpsmage[rval$psmage >= 4 & rval$psmage <= 8] <- 4
rval$cpsmage[rval$psmage >  8] <- 5
# table(rval$cpsmage)
rval$cpsmage <- factor(rval$cpsmage, levels = c(1,2,3,4,5), labels = c("1 yo", "2 yo", "3 yo", "4-8 yo", "8+ yo"))

rval.km <- survfit(Surv(psmser, status) ~ 1, conf.type = "none", type = "kaplan-meier", data = rval)
rval.km <- data.frame(time = rval.km$time, surv = rval.km$surv)
rval.km$csurv <- 1 - rval.km$surv

rval.km[rval.km$time == 21,]
rval.km[rval.km$time == 28,]

# windows(); plot(rval.km, xlab = "Days to first service", ylab = "S(t)")

windows(); ggplot(rval.km, aes(x = time)) + 
  geom_step(aes(y = surv)) +
  xlab("PSM to first service interval (days)") +
  ylab("Cumulative proportion to experience event") +
  scale_color_brewer(name = "Method", palette = "Set1")


# -------------------------------------------------------------------------------------------------------

