# Calving spread:

# Declarations:
start <- "01/2/2007"
end <- "01/7/2007"


# -------------------------------------------------------------------------------------------------------
# Select animals that calved during the analysis period:
id <- calvings$edate >= as.Date(start, format = "%d/%m/%Y") & calvings$edate <= as.Date(end, format = "%d/%m/%Y")
tcalvings <- calvings[id,1:5]

# Look up birth date from stock table using akey as the key:
tcalvings$bdate <- cows$bdate[match(tcalvings$cowkey, cows$cowkey)]

# Calculate age (in years) at the time of calving:
tcalvings$cage <- round(as.numeric((tcalvings$edate - tcalvings$bdate)/365), digits = 0)
tcalvings$cage[tcalvings$cage > 20] <- NA

# Create age categories:
tcalvings$ccage <- tcalvings$cage
tcalvings$ccage[tcalvings$cage >= 4 & tcalvings$cage <= 8] <- 4
tcalvings$ccage[tcalvings$cage >  8] <- 5
# table(tcalvings$ccage)
tcalvings$ccage <- factor(tcalvings$ccage, levels = c(2,3,4,5), labels = c("2 yo", "3 yo", "4-8 yo", "8+ yo"))


# -------------------------------------------------------------------------------------------------------
# Plot results:

date.bins <- seq(from = as.Date(start, format = "%d/%m/%Y"), to = as.Date(end, format = "%d/%m/%Y"), by = "1 week")

# windows(); hist(tcalvings$edate, breaks = date.bins, freq = TRUE, 
#   ylim = c(0, 100), col = "dark blue", border = "gray", 
#   xlab = "Date", ylab = "Number of calvings", main = "", cex.axis = 0.80)

windows(); ggplot(tcalvings, aes(x = edate)) +
  geom_histogram(binwidth = 7, colour = "gray") +
  labs(x = "Date", y = "Number of calving events") +  
  scale_fill_manual(values = c("#2f4f4f", "red")) + 
  guides(fill = FALSE) +
  ylim(0,100) +
  scale_x_date(breaks = date_breaks("1 week"), labels = date_format("%d %b %Y")) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))


# -------------------------------------------------------------------------------------------------------
