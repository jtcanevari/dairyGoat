# Conception rate analyses:

# Service date range:
start <- "1/06/1993"
end <- "01/11/1993"


# -------------------------------------------------------------------------------------------------------
# Assign services to each of the repro exams for each cow:

dw.conception <- function(start, end){
  # Select all services for all cows: 
  tservs <- servs %>%
    select(skey,cowkey,etype,serdate) %>%
    filter(!is.na(serdate)) %>%
    arrange(cowkey, serdate)
  # dim(tservs) # 1341
  
  # Select all repro events for all cows. Drop those ttrepro exams with DDUNC (due date unchanged):
  trepro <- repro %>%
    select(rkey,cowkey,etype,repdate,rreason,rdx1,rdx2) %>%
    filter(!rdx2 == "DDUNC") %>%
    arrange(cowkey, repdate)
  
  # Make a list of unique cow keys:
  ucow <- unique(tservs$cowkey)
  
  # Record the cowkey and the service key of the succesful service events:
  cowkey <- c(); sskey <- c()
  
  # Setup a data frame to save details for unrecorded services:
  uservs <- data.frame(skey = 0, cowkey = 0, etype = "SERVE", serdate = as.Date("1/01/1900", format = "%d/%m/%Y"), conc = 0)
  
  for(i in 1:length(ucow)){
    # List all service events for the cow of interest:
    ttservs <- tservs %>%
      filter(cowkey == ucow[i])
    names(ttservs) <- c("ekey","cowkey","etype","edate")
    ttservs$rdx2 <- ttservs$rdx1 <- ttservs$rreason <- NA   
    
    # Create a list of candidate repro exams for this service event:
    ttrepro <- trepro %>%
      filter(cowkey == ucow[i])
    names(ttrepro) <- c("ekey","cowkey","etype","edate","rreason","rdx1","rdx2")
    
    # Merge the service and repro exam tables and sort in order of edate:
    tmp <- rbind(ttservs, ttrepro)
    tmp$repserint <- NA
    
    tmp <- tmp %>%
      arrange(edate)
    
    # Work your way through each of the repro exams listed for the cow of interest. Only proceed if at least one reproductive exam is present:
    if(dim(ttrepro)[1] > 0){
      
      for(j in 1:nrow(ttrepro)){
        ttmp <- tmp %>%
          mutate(repserint = as.numeric(ttrepro$edate[j] - edate)) %>%
          filter(repserint >= 0)
        
        if(ttrepro$rdx2[j] == "LASTSERVICE" | ttrepro$rdx2[j] == "L SER"){
          ttmp <- ttmp %>%
            filter(etype == "SERVE")
          
          tsskey <- ttmp$ekey[nrow(ttmp)]
          sskey <- c(sskey,tsskey)
        }
        
        if(ttrepro$rdx2[j] == "2LASTSERVICE" | ttrepro$rdx2[j] == "SL SER"){
          ttmp <- ttmp %>%
            filter(etype == "SERVE")
          
          tsskey <- ttmp$ekey[nrow(ttmp) - 1]
          sskey <- c(sskey,tsskey)
        }
        
        if(ttrepro$rdx2[j] == "3LASTSERVICE" | ttrepro$rdx2[j] == "TL SER"){
          ttmp <- ttmp %>%
            filter(etype == "SERVE")
          
          tsskey <- ttmp$ekey[nrow(ttmp) - 2]
          sskey <- c(sskey,tsskey)
        }
        
        # If animal is pregnant and the number of weeks pregnant has been estimated:
        trdx2 <- grep(pattern = "WKS", x = ttrepro[j,"rdx2"], value = TRUE)
        trdx2 <- as.character(substr(trdx2, start = 1, stop = 6))
        
        if(length(trdx2) > 0){
          nwkspreg <- as.numeric(substr(trdx2, start = 1, stop = 2))
          
          # Find the repro-service interval within (nwkspreg * 7) - 7 to (nwkspreg * 7) + 7 and record the (successful) service key:
          id <- ttmp$repserint > ((nwkspreg * 7) - 7) & ttmp$repserint < ((nwkspreg * 7) + 7)
          
          # If the pregnancy can't be matched up with a service, we create one in the uservs (unmatched services table):
          if(sum(id) == 0){
            tuservs <- data.frame(skey = 0, cowkey = ttmp$cowkey[1], 
               etype = "SERVE", serdate = ttmp$edate[ttmp$etype == "REPRO" & ttmp$repserint == 0] - (nwkspreg * 7), conc = 1)
            uservs <- rbind(uservs, tuservs)
            
            tsskey <- 0
            sskey <- c(sskey,tsskey)  
          }
          
          # If the pregnancy can be matched up with a service, we add the identified successful service key to sskey:
          else if(sum(id) > 0){
            
            tsskey <- ttmp$ekey[id]
            sskey <- c(sskey,tsskey)        
          }
        }
      }
    }
  }
  
  uservs <- uservs[-1,]
  
  rval <- list(sskey = sskey, uservs = uservs)
  rval
}  
  
# We now have a vector listing the servkey for the successful services (sskey) and a data frame listing successful unrecorded service details (uservs). Add a 0 or 1 flag to data frame tservs to indicate which services resulted in a conception:

tservs$conc <- 0
tservs$conc[tservs$skey %in% sskey] <- 1

# Add the unrecorded services to the tservs table:
uservs <- uservs[-1,]
# tservs <- rbind(tservs, uservs)

# Cut the data down to the time frame of interest:
tservs <- tservs %>%
  filter(serdate >= as.Date(start, format = "%d/%m/%Y") & serdate <= as.Date(end, format = "%d/%m/%Y"))

sum(tservs$conc) / nrow(tservs)

# Cow age: 
tservs$birdate <- cows$birdate[match(tservs$cowkey, cows$cowkey)]

# Calculate age (in years) on date of service:
tservs$sage <- round(as.numeric((tservs$serdate - tservs$birdate)/365), digits = 0)
tservs$sage[tservs$sage > 20] <- NA

# Create age categories:
tservs$csage <- tservs$sage
tservs$csage[tservs$sage >= 4 & tservs$sage <= 8] <- 4
tservs$csage[tservs$sage >  8] <- 5
# table(tservs$csage)
tservs$csage <- factor(tservs$csage, levels = c(1,2,3,4,5), labels = c("1 yo", "2 yo", "3 yo", "4-8 yo", "8+ yo"))

# Service type:
tservs$stype <- servs$stype[match(tservs$skey, servs$skey)]

# Service sire:
tservs$ssire <- servs$ssire[match(tservs$skey, servs$skey)]

# Service technician:
tservs$stech <- servs$stech[match(tservs$skey, servs$skey)]

tservs$serv <- 1

# -------------------------------------------------------------------------------------------------------

rval <- tservs %>%
  group_by(csage)
rval <- data.frame(summarise(rval, conc = sum(conc), nserv = sum(serv)))
rval$crate <- round(rval$conc / rval$nserv, digits = 2); rval

# Service sire:
rval <- tservs %>%
  group_by(ssire)
rval <- data.frame(summarise(rval, conc = sum(conc), nserv = sum(serv)))
rval$crate <- round(rval$conc / rval$nserv, digits = 2); rval

# Technician:
rval <- tservs %>%
  group_by(stech)
rval <- data.frame(summarise(rval, conc = sum(conc), nserv = sum(serv)))
rval$crate <- round(rval$conc / rval$nserv, digits = 2); rval

# Time frame:
tservs$sweek <- format(tservs$serdate, format = "%Y-%U")

rval <- tservs %>%
  group_by(sweek)
rval <- data.frame(summarise(rval, conc = sum(conc), nserv = sum(serv)))
rval$crate <- round(rval$conc / rval$nserv, digits = 2); rval

