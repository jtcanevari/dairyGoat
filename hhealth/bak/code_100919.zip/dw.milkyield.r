# Milk production:

# Milk events between:
start <- "01/01/2016"
end <- "30/06/2016"


# -------------------------------------------------------------------------------------------------------

# Left join. Include all of the rows of x [calvings], and the matching rows of y [whcs]. Left join important because some cows with a PSM may remain unmated.
tprod <- production %>%
  left_join(x = calvings, y = production, by = "cowkey") %>%
  filter(prodate >= as.Date(start, format = "%d/%m/%Y") & prodate <= as.Date(end, format = "%d/%m/%Y")) %>%
  mutate(dim = as.numeric(prodate - clvdate)) %>%
  filter(dim >= 0 & dim < 400)
dim(tprod) # 213537

# Attach birth date:
tprod$birdate <- cows$birdate[match(tprod$cowkey, cows$cowkey)]

# Calculate age (in years) on date of weigh event:
tprod$page <- round(as.numeric((tprod$prodate - tprod$birdate)/365), digits = 0)

# Create age categories:
tprod$cpage <- tprod$page
tprod$cpage[tprod$page >= 4 & tprod$page <= 8] <- 4
tprod$cpage[tprod$page >  8] <- 5
# table(tprod$cpage)
tprod$cpage <- factor(tprod$cpage, levels = c(1,2,3,4,5), labels = c("1 yo", "2 yo", "3 yo", "4-8 yo", "8+ yo"))

windows(); ggplot(tprod, aes(x = dim, y = htvoltot)) + 
  geom_point() +
  # facet_grid(cpage ~ .) +
  xlab("Days in milk") +
  ylab("Daily milk yield (L)") +
  scale_color_brewer(name = "Method", palette = "Set1")




