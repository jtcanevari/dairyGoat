library(dplyr); library(survival); library(RODBC); library(ggplot2); library(scales); library(tidyr)


# Declarations:
clvstart <- "01/03/1993"
clvstop <- "31/05/1993"

setwd("D:\\Temp\\dairy\\data\\Massey-01_1993")


# -------------------------------------------------------------------------------------------------------

# Period:
period <- c("June-2015", "Sep-2015", "Nov-2015", "Mar-2016", "Jun-2016", "Sep-2016")
nborn <- c((15541-15301+1), (15805-15575+1), 566, (152916-152551+1), (162240-162001+1), (162675-162241+1))
nsurv <- c(211,197,505,335,203,324)
ndead <- nborn - nsurv

dat <- data.frame(period, ndead, nborn)

rval <- epi.conf(as.matrix(cbind(dat$ndead, dat$nborn)), ctype = "prevalence", method = "exact", N = 1000, design = 1, conf.level = 0.95) * 100
rval <- round(rval, digits = 0)
rval <- data.frame(period, est = rval$est, low = rval$lower, upp = rval$upper)

windows(); ggplot(rval, aes(x = period, y = est)) +
  geom_errorbar(aes(ymin = low, ymax = upp), width = 0.1) +
  geom_point() +
  xlab("Date") +
  ylab("Preweaning mortality rate")



# Calved per season
Mar15 <- calv[year(calv$calvDate) == "2015" & (month(calv$calvDate) == "2" | month(calv$calvDate) == "3" | month(calv$calvDate) == "4"), ]
Jun15 <- calv[year(calv$calvDate) == "2015" & (month(calv$calvDate) == "5" | month(calv$calvDate) == "6" | month(calv$calvDate) == "7"), ]
Sep15 <- calv[year(calv$calvDate) == "2015" & (month(calv$calvDate) == "8" | month(calv$calvDate) == "9" | month(calv$calvDate) == "10"), ]
Nov15 <- calv[year(calv$calvDate) == "2015" & (month(calv$calvDate) == "11" | month(calv$calvDate) == "12"), ]
Mar16 <- calv[year(calv$calvDate) == "2016" & (month(calv$calvDate) == "2" | month(calv$calvDate) == "3" | month(calv$calvDate) == "4"), ]
Jun16 <- calv[year(calv$calvDate) == "2016" & (month(calv$calvDate) == "5" | month(calv$calvDate) == "6" | month(calv$calvDate) == "7"), ]

#expected calved (ie does calved times the expected litter size)
eSep15 <- nrow(Sep15) * alsize/2
eNov15 <- nrow(Nov15) * alsize/2 
eMar16 <- nrow(Mar16) * alsize/2 
eJun16 <- nrow(Jun16) * alsize/2 

#VID tagged

# June 15  15575 - 15805
# Sept 15  15812 - 151377
# Nov 15  152551 - 152916
# March 16  162001 - 162240
# June 16  162241 - 162675
# Sept 16  162686 - 163008

tJun15 <- length(c(15575:15805))
tSep15 <- length(c(15812:16000, 151001:151377))
tNov15 <- length(c(152551:152916))
tMar16 <- length(c(162001:162240))
tJun16 <- length(c(162241:162675))
tSep16 <- length(c(162686:163008))

# Create table
S_EXPECTED = c(eSep15,eNov15, eMar16,eJun16 )
S_EXPECTED <- round(S_EXPECTED,0)
VID_tagged = c(tSep15,tNov15,tMar16,tJun16)
stbths <- data.frame(S_EXPECTED = S_EXPECTED, VID_tagged = VID_tagged)
stbths$STBTH <- round((1-(VID_tagged/S_EXPECTED)) * 100,1)

# stbths

#calculate for finantial year
sb_dead <- sum(stbths$S_EXPECTED) - sum(stbths$VID_tagged)
sb_exposed <- sum(stbths$S_EXPECTED)



###############################
#### Pre-weaning Mortality ####

#VIDs
# March 15 15301 - 15541
# June 15  15575 - 15805
# Sept 15  15812 - 151377
# Nov 15  152551 - 152916
# March 16  162001 - 162240
# June 16  162241 - 162675
# Sept 16  162686 - 163008
# Some of these kids had been sent away to be reared on another farm (!!!!!)

#Calculate PRE-WEANING MORTALITY based on number of kids that got their first tag and number of kidds that got an EID

cows <- read.csv("LOC_cows.csv", strip.white = TRUE)

VIDtag_Mar15 <- c(15301:15541)
EIDtag_Mar15 <- cows[cows$CowNumber %in% VIDtag_Mar15,]
# round((1-(211/(15541-15301+1)))*100,1) #12.4%

VIDtag_Jun15 <- c(15575:15805)
EIDtag_Jun15 <- cows[cows$CowNumber %in% VIDtag_Jun15,]
# round((1-(197/(15805-15575+1)))*100,1) # 14.7%

VIDtag_Sep15 <- c(15812:15999,151000:151377)
EIDtag_Sep15 <- cows[cows$CowNumber %in% VIDtag_Sep15,]
# round ((1-(505/566))*100,1) # 10.8%

VIDtag_Nov15 <- c(152551 : 152916)
EIDtag_Nov15 <- cows[cows$CowNumber %in% VIDtag_Nov15,]
# round((1-(335/(152916 - 152551+1)))*100,1) # 8.5%

VIDtag_Mar16 <- c(162001:162240)
EIDtag_Mar16 <- cows[cows$CowNumber %in% VIDtag_Mar16,]
# round((1-(203 / (162240-162001+1)))*100,1) #15.4%

VIDtag_Jun16 <- c(162241:162675)
EIDtag_Jun16 <- cows[cows$CowNumber %in% VIDtag_Jun16,]
# round((1-(324 / (162675 - 162241 +1)))*100,1) #25.5%

#calculate for 2015-16 finantial year

PW_Exposed <- length(VIDtag_Sep15) + length(VIDtag_Nov15) + length(VIDtag_Mar16) +length(VIDtag_Jun16)
weaned <- rbind(EIDtag_Sep15, EIDtag_Nov15, EIDtag_Mar16, EIDtag_Jun16)
n_weaned <- nrow(weaned)
pw_dead <- PW_Exposed - n_weaned
pwmort <- pw_dead / PW_Exposed

pwtable <- data.frame(PW_Exposed = PW_Exposed, Dead = pw_dead, Mortality_Risk = pwmort)



@@@

# Select animals that calved during the analysis period:
id <- calvings$edate >= as.Date(start, format = "%d/%m/%Y") & calvings$edate <= as.Date(end, format = "%d/%m/%Y")
tcalvings <- calvings[id,1:5]

# Look up birth date from stock table using akey as the key:
tcalvings$bdate <- cows$bdate[match(tcalvings$cowkey, cows$cowkey)]

# Calculate age (in years) at the time of calving:
tcalvings$cage <- round(as.numeric((tcalvings$edate - tcalvings$bdate)/365), digits = 0)
tcalvings$cage[tcalvings$cage > 20] <- NA

# Create age categories:
tcalvings$ccage <- tcalvings$cage
tcalvings$ccage[tcalvings$cage >= 4 & tcalvings$cage <= 8] <- 4
tcalvings$ccage[tcalvings$cage >  8] <- 5
# table(tcalvings$ccage)
tcalvings$ccage <- factor(tcalvings$ccage, levels = c(2,3,4,5), labels = c("2 yo", "3 yo", "4-8 yo", "8+ yo"))


# -------------------------------------------------------------------------------------------------------
# Plot results:

date.bins <- seq(from = as.Date(start, format = "%d/%m/%Y"), to = as.Date(end, format = "%d/%m/%Y"), by = "1 week")

# windows(); hist(tcalvings$edate, breaks = date.bins, freq = TRUE, 
#   ylim = c(0, 100), col = "dark blue", border = "gray", 
#   xlab = "Date", ylab = "Number of calvings", main = "", cex.axis = 0.80)

windows(); ggplot(tcalvings, aes(x = edate)) +
  geom_histogram(binwidth = 7, colour = "gray") +
  labs(x = "Date", y = "Number of calving events") +  
  scale_fill_manual(values = c("#2f4f4f", "red")) + 
  guides(fill = FALSE) +
  ylim(0,100) +
  scale_x_date(breaks = date_breaks("1 week"), labels = date_format("%d %b %Y")) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))


# -------------------------------------------------------------------------------------------------------
