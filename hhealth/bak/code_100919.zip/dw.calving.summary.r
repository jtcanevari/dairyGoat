# Calving summary:

# Calvings between:
start <- "10/3/2007"
end <- "01/7/2007"


# -------------------------------------------------------------------------------------------------------
# Select animals that calved during the analysis period:
id <- calvings$edate >= as.Date(start, format = "%d/%m/%Y") & calvings$edate <= as.Date(end, format = "%d/%m/%Y")
tcalvings <- calvings[id,1:5]

# Look up birth date from stock table using akey as the key:
tcalvings$bdate <- cows$bdate[match(tcalvings$cowkey, cows$cowkey)]

# Calculate age (in years) at the time of calving:
tcalvings$cage <- round((tcalvings$edate - tcalvings$bdate)/365, digits = 0)
tcalvings$cage[tcalvings$cage > 20] <- NA

# Create age categories:
tcalvings$ccage <- tcalvings$cage
tcalvings$ccage[tcalvings$cage >= 4 & tcalvings$cage <= 8] <- 4
tcalvings$ccage[tcalvings$cage >  8] <- 5
# table(tcalvings$ccage)
tcalvings$ccage <- factor(tcalvings$ccage, levels = c(2,3,4,5), labels = c("2 yo", "3 yo", "4-8 yo", "8+ yo"))

# Fix up calving type:
tcalvings$ctype <- as.character(tcalvings$ctype)
tcalvings$ctype[tcalvings$ctype == ""] <- "UNK"
tcalvings$ctype <- factor(tcalvings$ctype, levels = c("NORMAL", "INDUCE", "PREM", "ABORT", "UNK"))


# Tabulate number of calving events by age group (as rows) and calving type (as columns):
# table(tcalve$ccage, tcalve$type)
rval <- addmargins(table(tcalvings$ccage, tcalvings$ctype))
dimnames(rval)[[1]][5] <- "TOTAL"
dimnames(rval)[[2]][6] <- "TOTAL"
rval

