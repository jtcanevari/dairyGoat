library(shiny)

shinyUI(fluidPage(
 
# Application title:
  titlePanel("Submission rate report"),
  
# Input variables:  
  sidebarPanel(
    dateInput("sstart", label = "Planned Start of Mating start:", value = "1993-06-01", min = NULL, max = NULL, format = "dd-mm-yyyy"),
    dateInput("sstop",  label = "Planned Start of Mating end:", value = "1993-08-10", min = NULL, max = NULL, format = "dd-mm-yyyy"),
    submitButton("Update View")
  ),

# Report output:  
  mainPanel(
    h4("Number of submission events by week following Planned Start of Mating:"),
    tableOutput("tblSubmissionCounts"),
    tags$br(),
    tags$br(),

    h4("Percentage of submission events by week following Planned Start of Mating:"),
    tableOutput("tblSubmissionPercent"),
    tags$br(),
    tags$br(),
    tags$br(),
    tags$br(),
        
    h4("Cumulative proportion of does to be mated following Planned Start of Mating:"),
    plotOutput("pltSubmission"),
    # tags$footer("Gray line at the back shows herd average weights by age"),
    tags$br()
    )
  )
)