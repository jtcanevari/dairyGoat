library(shiny)

shinyUI(fluidPage(
 
# Application title:
  titlePanel("Kidding report"),
  
# Input variables:  
  sidebarPanel(
    dateInput("cstart", label = "Planned Start of Kidding:", value = "2016-06-01", min = NULL, max = NULL, format = "dd-mm-yyyy"),
    dateInput("cstop",  label = "Date to end kidding analysis:", value = "2016-07-31", min = NULL, max = NULL, format = "dd-mm-yyyy"),
    submitButton("Update View")
  ),

# Report output:  
  mainPanel(
    h4("Summary of kidding outcomes for period:"),
    tags$br(),
    tableOutput("tblCalvingOutcomes"),
    tags$footer("PREM: premature; ABORT: aborted; UNK: Unknown birth outcome."),
    tags$br(),
    tags$br(),
    tags$br(),
    tags$br(),
    
    h4("Number of kidding events by week following Planned Start of Kidding:"),
    tableOutput("tblCalvingCounts"),
    tags$br(),
    tags$br(),

    h4("Percentage of kidding events by week following Planned Start of Kidding:"),
    tableOutput("tblCalvingPercent"),
    tags$br(),
    tags$br(),
    tags$br(),
    tags$br(),
        
    h4("Number of kidding events as a function of calendar date:"),
    plotOutput("pltCalvings"),
    # tags$footer("Gray line at the back shows herd average weights by age"),
    tags$br()
    )
  )
)